package com.example.notetap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class NoteAdapter extends BaseAdapter {

    Context mContext;
    ArrayList<Note> notes = new ArrayList<>();

    public NoteAdapter(Context context, ArrayList<Note> notes)
    {
        mContext = context;
        this.notes = notes;

    }


    @Override
    public int getCount() {
        return notes.size();
    }

    @Override
    public Object getItem(int position) {
        return notes.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
        {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.listview_item, parent,false);

        }

        NoteMaker tempNote = (NoteMaker) getItem(position);

        TextView noteTitle = (TextView)convertView.findViewById(R.id.noteTitle);

        noteTitle.setText(tempNote.getTitle());




        return null;
    }
}
