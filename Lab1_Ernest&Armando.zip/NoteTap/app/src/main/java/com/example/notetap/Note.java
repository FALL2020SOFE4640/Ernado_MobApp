package com.example.notetap;

public class Note {
    String title;
    String writing;
    String description;
    public Note(String title, String description, String writing)
    {
        this.title = title;
        this.description = description;
        this.writing = writing;
    }

    public String getDescription() {
        return description;
    }

    public String getTitle() {
        return title;
    }

    public String getWriting() {
        return writing;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setWriting(String writing) {
        this.writing = writing;
    }
}
