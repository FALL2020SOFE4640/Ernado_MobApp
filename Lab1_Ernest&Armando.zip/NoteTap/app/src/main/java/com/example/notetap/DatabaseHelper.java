package com.example.notetap;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "note_maker.db";
    public static final String TABLE_NAME = "notes";
    public static final String COL1 = "id";
    public static final String COL2 = "title";
    public static final String COL3 = "description";
    public static final String COL4 = "note";


    public DatabaseHelper(@Nullable Context context) {
        super(context, TABLE_NAME, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createTableSQl ="CREATE TABLE " + TABLE_NAME + "( " +
                COL1 + " INT(6) PRIMARY KEY," +
                COL2 + " VARCHAR(30) NOT NULL," +
                COL3 + " VARCHAR(30) NOT NULL," +
                COL4 + " VARCHAR(30) NOT NULL";
        sqLiteDatabase.execSQL(createTableSQl);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //backup
        sqLiteDatabase.execSQL("drop table if exists " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }


    public Boolean addNewRecord(String title,String description,String note){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2,title);
        contentValues.put(COL3,description);
        contentValues.put(COL4,note);


        long result = db.insert(TABLE_NAME,null,contentValues);
        if (result ==0) return false;
        else return true;


    }
}