package com.example.notetap;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class NoteMaker extends AppCompatActivity implements View.OnClickListener {
    DatabaseHelper noteDatabaseHelper;
    private EditText noteTxt, titlTxt, descTxt;
    private Button CnclBttn, SaveBttn;
    public ListView listView;

    public ArrayList<Note> notes = new ArrayList<>();


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.note_maker);
        CnclBttn = (Button) findViewById(R.id.button_cancel);
        SaveBttn = (Button) findViewById(R.id.button_save);
        titlTxt = (EditText) findViewById(R.id.editTextTitle);
        noteTxt = (EditText) findViewById(R.id.editTextTask);
        descTxt = (EditText) findViewById(R.id.editTextDesc);

        noteDatabaseHelper = new DatabaseHelper(this);
        listView = (ListView)findViewById(R.id.list_view);
        SaveBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titlTxt.getText().toString();
                String description = descTxt.getText().toString();
                String note = noteTxt.getText().toString();
                AddData(title,description,note);
            }
        });











    }


    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);


    }

    public void AddData(String title, String description, String note)
    {
        Note newNote = new Note(title,description,note);
        notes.add(newNote);
        boolean insertData = noteDatabaseHelper.addNewRecord(title,description,note);
        if (insertData){
            toastMessage("Nice Job");
        }
        else {
            toastMessage("Bruh");
        }
        Intent intent = new Intent(this, MainActivity.class);

        fillListView();
        startActivity(intent);


    }


    private void toastMessage(String message)
    {
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }

    public void fillListView()
    {
        NoteAdapter myNoteAdapter = new NoteAdapter(NoteMaker.this, notes);
        listView.setAdapter(myNoteAdapter);
    }


}



